// Generator data contoh penjualan untuk dashboard Power BI.
// Jalankan: node scripts/generate_data.js
const fs = require("fs");
const path = require("path");

const OUT = path.join(__dirname, "..", "data", "sales.csv");
const ROWS = 5000;
const START = new Date(Date.UTC(2023, 0, 1));
const END = new Date(Date.UTC(2024, 11, 31));

const regions = {
  "Jawa Barat": ["Bandung", "Bekasi", "Bogor"],
  "DKI Jakarta": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Barat"],
  "Jawa Tengah": ["Semarang", "Solo", "Magelang"],
  "Jawa Timur": ["Surabaya", "Malang", "Sidoarjo"],
  "Sumatera": ["Medan", "Palembang", "Padang"],
  "Sulawesi": ["Makassar", "Manado"],
};
const products = {
  "Elektronik": [["Headset Bluetooth", 250000], ["Power Bank 10000mAh", 180000], ["Smart TV 32 inci", 2400000]],
  "Fashion": [["Kemeja Batik", 150000], ["Sepatu Sneakers", 350000], ["Tas Ransel", 220000]],
  "Makanan": [["Kopi Arabika 250g", 85000], ["Teh Melati 100g", 25000], ["Madu Hutan 500ml", 95000]],
  "Rumah Tangga": [["Blender", 450000], ["Set Panci", 380000], ["Rice Cooker", 520000]],
};
const channels = ["Online", "Toko Fisik", "Marketplace", "Reseller"];

// Deterministic PRNG agar hasil selalu sama setiap dijalankan.
let seed = 42;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
const pick = (arr) => arr[Math.floor(rnd() * arr.length)];

const days = Math.round((END - START) / 86400000);
const header = ["OrderID","OrderDate","Region","Kota","Kategori","Produk","Channel","Qty","HargaSatuan","Diskon","Penjualan","HPP","Profit"];
const lines = [header.join(",")];

for (let i = 1; i <= ROWS; i++) {
  const date = new Date(START.getTime() + Math.floor(rnd() * days) * 86400000);
  const region = pick(Object.keys(regions));
  const kota = pick(regions[region]);
  const kategori = pick(Object.keys(products));
  const [produk, harga] = pick(products[kategori]);
  const channel = pick(channels);
  const qty = 1 + Math.floor(rnd() * 5);
  const diskonPct = pick([0, 0, 0, 5, 10, 15]);
  const diskon = diskonPct / 100;
  const hargaSatuan = Math.round(harga * (0.95 + rnd() * 0.1) / 1000) * 1000;
  const penjualan = Math.round(qty * hargaSatuan * (1 - diskon));
  const hpp = Math.round(qty * hargaSatuan * 0.6);
  const profit = penjualan - hpp;
  const tgl = date.toISOString().slice(0, 10);
  const row = [
    `ORD-${String(i).padStart(5, "0")}`, tgl, region, kota, kategori,
    `"${produk}"`, channel, qty, hargaSatuan, diskon.toFixed(2), penjualan, hpp, profit,
  ];
  lines.push(row.join(","));
}

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, lines.join("\n") + "\n", "utf8");
console.log(`Berhasil membuat ${ROWS} baris -> ${OUT}`);
