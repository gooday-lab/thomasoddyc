# Power BI Project – Dashboard Penjualan

Project Power BI dalam format **PBIP** (teks, bisa di-versioning dengan Git).

## Isi Project

```
powerbi-sales-dashboard/
├── SalesDashboard.pbip                 # file utama — double-click untuk membuka
├── data/
│   └── sales.csv                       # data contoh (5.000 transaksi, 2023–2024)
├── scripts/
│   └── generate_data.js                # generator ulang data contoh (Node.js)
├── SalesDashboard.SemanticModel/       # data model: tabel, relasi, measure DAX
│   └── definition/
│       ├── tables/Sales.tmdl           # tabel fakta + measure
│       ├── tables/Calendar.tmdl        # tabel tanggal (dibuat otomatis di Power Query)
│       ├── relationships.tmdl          # relasi Sales[OrderDate] -> Calendar[Date]
│       └── expressions.tmdl            # parameter DataFolder (lokasi CSV)
└── SalesDashboard.Report/              # halaman laporan (visual)
    └── definition/pages/...            # 1 halaman: KPI, slicer, tren, bar chart
```

## Cara Menjalankan

1. Install **Power BI Desktop** (Microsoft Store atau https://aka.ms/pbidesktop).
2. Pastikan fitur PBIP aktif: *File → Options and settings → Options → Preview features →
   "Power BI Project (.pbip) save option"* (di versi terbaru sudah default aktif).
3. Buka `SalesDashboard.pbip`.
4. Jika muncul error sumber data, cek parameter **DataFolder**:
   *Transform data → Manage Parameters → DataFolder* dan arahkan ke folder `data` di komputer Anda.
5. Klik **Refresh** bila data belum muncul.

## Isi Dashboard

| Visual | Keterangan |
|---|---|
| Kartu KPI | Total Penjualan, Total Profit, Margin %, Jumlah Transaksi |
| Slicer | Filter Tahun |
| Line chart | Tren penjualan bulanan (sumbu: `Calendar[YearMonth]`) |
| Column chart | Penjualan per Region |
| Column chart | Profit per Kategori |

## Measure DAX (tabel `Sales`)

| Measure | Rumus |
|---|---|
| Total Penjualan | `SUM(Sales[Penjualan])` |
| Total HPP | `SUM(Sales[HPP])` |
| Total Profit | `SUM(Sales[Profit])` |
| Margin % | `DIVIDE([Total Profit], [Total Penjualan])` |
| Total Qty | `SUM(Sales[Qty])` |
| Jumlah Transaksi | `DISTINCTCOUNT(Sales[OrderID])` |
| Rata-rata per Transaksi | `DIVIDE([Total Penjualan], [Jumlah Transaksi])` |
| Penjualan Tahun Lalu | `CALCULATE([Total Penjualan], SAMEPERIODLASTYEAR(Calendar[Date]))` |
| YoY % | `DIVIDE([Total Penjualan] - [Penjualan Tahun Lalu], [Penjualan Tahun Lalu])` |

## Mengganti dengan Data Asli

1. Siapkan file CSV dengan kolom: `OrderID, OrderDate, Region, Kota, Kategori, Produk, Channel, Qty, HargaSatuan, Diskon, Penjualan, HPP, Profit`.
2. Letakkan di folder `data/` (atau ubah parameter `DataFolder`).
3. Jika nama kolom berbeda, ubah langkah `Typed` di `tables/Sales.tmdl` atau ubah nama kolom di Power Query.

## Membuat Ulang Data Contoh

```bash
node scripts/generate_data.js
```

## Catatan

- Struktur file dibuat secara manual sesuai format PBIP. Jika Power BI Desktop
  menampilkan pesan error saat dibuka, cara paling aman adalah membuat file `.pbix` baru
  dengan **Get Data → Text/CSV** memakai `data/sales.csv`, lalu menyalin measure dari tabel di atas
  dan membuat visual sesuai tabel "Isi Dashboard".
